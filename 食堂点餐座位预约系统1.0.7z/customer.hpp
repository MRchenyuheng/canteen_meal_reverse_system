#include"user.hpp"

#pragma once

#include<fstream>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<vector> 



const int N = 1000;

using namespace std;

typedef pair<int, int> PII;

vector<string>now_log;
vector<PII>now_map;
char maps[N][N];
bool is_set[N][N];
int mapx;
int mapy;


string get_time2()
{
	time_t now = time(NULL);
	tm* tm_t = localtime(&now);
	std::stringstream ss;
	ss << tm_t->tm_year + 1900 << "-" ;
	if(tm_t->tm_mon + 1 < 10) ss << 0;
	ss << tm_t->tm_mon + 1 << "-" ;
	if(tm_t->tm_mday < 10) ss << 0;
	ss << tm_t->tm_mday	<< " " ;
    if(tm_t->tm_hour < 10) ss << 0;
	ss <<  tm_t->tm_hour << ":" ;
	if(tm_t->tm_min < 10) ss << 0;
	ss << tm_t->tm_min << ":" ;
	if(tm_t->tm_sec < 10) ss << 0;
	 ss << tm_t->tm_sec;
 
   return ss.str();
}
 
 
 

class customer : public user
{
	
public:
	void reverse_meal();
	void time_log_to_map(string hour,string min);
	void draw_map(string hour,string min);
	void init_map();
	bool check(string hour,string min,string sitx,string sity);
	void show_map_now();
	void show_the_log();

	 
	
private:
	string user_id;
	string user_name;
		
};

void customer::show_the_log()
{
	ifstream read;
	string log;
	read.open("reverse_log.txt",ios::in);
	int cnt = 1;
	while(getline(read,log))
	{ 
	
		if(log_to_item(log,7) == get_name())
		{   
		    cout << cnt << ":" << endl; cnt ++; 
			cout <<"�ò�ʱ��:" << log_to_item(log,1) << ":" << log_to_item(log,2) << endl;
	        cout <<"�ò͵ص�:" <<"(" << log_to_item(log,3) << "," << log_to_item(log,4) << ")" << endl; 
         	cout <<"��������:" <<  log_to_item(log,5) << endl; 
	        cout <<"���:" << log_to_item(log,6) << "Ԫ" << endl;
	        if(log_to_item(log,10) == "0") cout << "����״̬:���Ȼ��������У���ȴ�!" << endl;
	        else cout << "����״̬:�����Ѿ��������!" << endl;

	        cout << endl;
		}
	}
}

void customer::show_map_now()
{
	string time_now;
	time_now = get_time2();
	cout << time_now << endl;
	int ps_at_st_hour = time_now.find(" ") + 1;
	int ps_at_end_hour = time_now.find(":",ps_at_st_hour)  + 1; 
	string hour_now =  time_now.substr( ps_at_st_hour,ps_at_end_hour - ps_at_st_hour - 1) ; 
	
//	int ps_at_st_min = time_now.find(":",ps_at_end_hour) + 1;
	int ps_at_end_min = time_now.find(":",ps_at_end_hour)  + 1; 
    string min_now =  time_now.substr( ps_at_end_hour,ps_at_end_min - ps_at_end_hour - 1) ; 
    
    draw_map(hour_now,min_now);
	
	
}

void customer::reverse_meal()
{   
    
   // string meallog;
	
	string log;
	
	system("cls");
	cout << "�������ڵ��ʱ��Ԥ��(1/4)" << endl;
	cout << "����ѡ���òͿ�ʼʱ�䣺"<< endl;
	cout << "�ò��޶�20����:" << endl;
	cout << "ʱ��" ;string hour;cin >> hour;
	cout << "�֣�" ;string min;cin >> min;
	//cout << "ʱ��" ;string sec;cin >> sec;
	log += hour + ' ' + min + ' '; 
	system("pause");
	
	
	system("cls");
	cout << "�������ڵ����λԤ��(2/4)" << endl;
    draw_map(hour,min);
    
    cout << "���������꣬ѡ����λ:" << endl;
    string x;string y;
    cout << "x: ";cin >> y; 
	cout << "y: ";cin >> x;
    log += x + ' ' + y + ' ';
    system("pause");
    
    
    system("cls");
    cout << "�������ڵ�Ͳ�ƷԤ��(3/4)" << endl;
	show_menu();
    cout << "��ѡ���Ʒ���:" << endl;
   ifstream read;string line;
    string item;cin >> item;
    
    
    read.open("menu.txt");
	while(getline(read,line))
	{   
	    int pos1 = line.find(" ") + 1;
		string lines = line.substr(0, pos1 - 1);
		if(lines == item) {
		log += line + ' ';

     	}
	}
	read.close();
	system("pause");
	
    log += get_name() + ' ' + get_id() + ' ';
   
    
    
    system("cls");
    cout << "�������ڵ��Ԥ��(4/4)" << endl;
    cout << "���ڽ��ж���ȷ��" << endl; 


 	cout <<"�ò���:" << log_to_item(log,7) << endl;
 	cout <<"�ò��˺�ID:" << log_to_item(log,8) << endl;
	cout <<"�ò�ʱ��:" << log_to_item(log,1) << ":" << log_to_item(log,2) << endl;
	cout <<"�ò͵ص�:" <<"(" << log_to_item(log,3) << "," << log_to_item(log,4) << ")" << endl; 
	cout <<"��������:" <<  log_to_item(log,5) << endl; 
	cout <<"���:" << log_to_item(log,6) << "Ԫ" << endl;
   
    cout << "����һ��ȷ�ϣ����̱��ͣ����������ģ�" << endl; 
	cout << "ȷ�϶�������:yes"<< endl;
	cout << "ȡ����������:no" << endl;
	
	string is_sure;cin >> is_sure; 
	
	if(is_sure == "yes"){
    if(check(hour,min,x,y)) {
	  cout << "Ԥ��ʧ�ܣ���ǰλ���Ѿ�������Ԥ�������ߵ�ǰλ�ò���Ԥ����" << endl;
	  
    }
    else{
    //////////////////////////////////////////////////////////////
	   ifstream write_id;
	    ofstream write;
		string ids;int id;
	    queue<string> temp; 
	    write_id.open("index.txt");
	    
	    while(getline(write_id,line))
	{   
	    int pos1 = line.find(" ") + 1;
		int pos2 = line.find(" ",pos1);
		string lines = line.substr(0, pos1 - 1);
		
		if(lines != "log_id") temp.push(line);
		else 
		{
			ids = line.substr(pos1, pos2 - pos1) ;
			istringstream ss(ids);
            ss >> id;
            line = lines + " " + to_string(id + 1);
            temp.push(line);
		}
		
	}
	write_id.close();
	
	//id
	write.open( "index.txt",ios::in | ios::trunc);
	
	
	while(!temp.empty())
	{     
	    if(temp.front() != " ")  
		write << temp.front() << endl;
		temp.pop();
	}
	
	write.close();	
	//////////////////////////////////////////////////////////
	
	log += ids + ' '; 
    ofstream writes;
	writes.open( "reverse_log.txt",ios::app);
	if (!writes.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file to read\n";
			return;
		} 
		
		string status = "0";
        log += status;
        
		writes  << endl << log;
		writes.close();
		cout << "�����Ѿ�ȷ�ϣ�"<< endl;
	}
  }
  else cout << "ȡ���ɹ���"<< endl;
}

void customer::time_log_to_map(string hour,string min)
{   
    int h;int m;
    int start_time;int end_time;
	istringstream sh(hour);
	istringstream sm(min);
	sh >> h;
	sm >> m;
	start_time = h * 60 + m;
	end_time = start_time + 20;
	

	ifstream read;
	read.open("reverse_log.txt");
	
	string line;
	
	while(getline(read,line))
	{   
	    int pos1 = line.find(" ") + 1;
		int pos2 = line.find(" ",pos1);
		
		string new_hour = line.substr(0, pos1 - 1);
		string new_min = line.substr(pos1, pos2 - pos1) ;
		istringstream snh(new_hour);
	    istringstream snm(new_min);
	    int new_h; snh >> new_h;
	    int new_m; snm >> new_m;
	    int new_time = 60 * new_h + new_m;
	    
	    if(new_time >= start_time && new_time <= end_time)
	    now_log.push_back(line);
	    
	}
	read.close();
	
	while(!now_log.empty())
	{   
	     //cout << "not_empty" << endl;
	    string t = now_log.back();
	    now_log.pop_back();
	    //cout << t << endl; 
	    int pos1 = line.find(" ") + 1;
	    int pos2 = line.find(" ",pos1) + 1;
	    int pos3 = line.find(" ",pos2) + 1; string str_x = t.substr(pos2,pos3 - pos2);
	    int pos4 = line.find(" ",pos3) + 1; string str_y = t.substr(pos3,pos4 - pos3);
	    
	    //cout << "str_x "<< str_x  << "str_y "<<  str_y << " " << pos1 << ' ' << pos2 << ' ' << pos3 << ' ' << pos4 << endl;
	    
	    istringstream xxx(str_x);
	    istringstream yyy(str_y);
	    int xx; xxx >> xx;
	    int yy; yyy >> yy;
	    
	    now_map.push_back({xx,yy});
	}
//	cout << 1 << endl;
	
//	while(!now_map.empty())
//	{
//		PII t = now_map.back(); now_map.pop_back();
//	
//		cout << t.first << ' ' << t.second << endl; 
//	}

	
	
	
}

void customer::draw_map(string hour,string min)
{   
   // system("pause");
  //  cout << 2 << endl;
    
    time_log_to_map(hour,min);
  //  system("pause");
   
    init_map();
    
	while(!now_map.empty())
	{
		PII t = now_map.back(); now_map.pop_back();
		if(!is_set[t.first][t.second])
		maps[t.first][t.second] = '1';
	}
	
	for(int i = 0;i <= mapx;i ++)
	{for(int j = 0;j <= mapy;j ++)
	{
	   if(j == 0) cout  << left << setw(3) << i ; 
	   else if(i == 0) cout << left << setw(3) <<  j;
       else cout << left << setw(3) << maps[i][j] ;
    }
	  cout << endl; 
    }
	
}

void customer::init_map()
{
    
    
    for(int i = 0;i < N;i ++)
    for(int j = 0;j < N;j ++)
      maps[i][j] = '0';
      
	ifstream read;
	string map;
	read.open("map.txt",ios::in);
		if (!read.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file map.txt to read\n";
			return;
		}
	
	bool f = true;
	
	while(getline(read,map))
	  {
	  	int pos1 = map.find(" ") + 1;
		int pos2 = map.find(" ",pos1);
		
		string sxx = map.substr(0, pos1 - 1);
		string syy = map.substr(pos1, pos2 - pos1) ;
		istringstream xxx(sxx);
	    istringstream yyy(syy);
	    int x_int; xxx >> x_int;
	    int y_int; yyy >> y_int;
	    if(f)
	    {
	    	 mapx = x_int;
	    	 mapy = y_int;
	    	 f = false;
		}
		else {
		maps[x_int][y_int] = '#';
	    is_set[x_int][y_int] = true;
	   }
	    
	  }
    
    read.close();
    
}

bool customer::check(string hour,string min,string sitx,string sity)
{ 
	//while(!)
	time_log_to_map(hour,min);
	init_map();
	while(!now_map.empty())
	{
		PII t = now_map.back(); now_map.pop_back();
		is_set[t.first][t.second] = true;
	}
	    istringstream xxx(sitx);
	    istringstream yyy(sity);
	    int x_int; xxx >> x_int;
	    int y_int; yyy >> y_int;
    return is_set[x_int][y_int];
}

