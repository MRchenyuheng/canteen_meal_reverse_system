#include"user.hpp"

#pragma once

#include<iostream>
#include<algorithm>
#include<cstring>
#include<fstream>
#include<iomanip> 
#include<queue> 
#include<sstream>

using namespace std;

class store_keeper : public user
{

public:
	void add_menu_item();
	void delt_menu_item();
	void show_log_need_to_deal();
	void deal_with_the_log();
	
	
private:
	string user_id;
	string user_name;
		
};

void store_keeper::show_log_need_to_deal()
{
	ifstream read;
	string log;
	read.open("reverse_log.txt",ios::in);
	while(getline(read,log))
	{
      	if(log_to_item(log,10) == "0")
		{   
		    cout << "����id: " << log_to_item(log,9) << endl;
			cout <<"�ò�ʱ��:" << log_to_item(log,1) << ":" << log_to_item(log,2) << endl;
         	cout <<"��������:" <<  log_to_item(log,5) << endl; 
	        cout <<"���:" << log_to_item(log,6) << "Ԫ" << endl;
	        cout << endl;
		}
	}
	read.close();
}

void store_keeper :: deal_with_the_log()
{   

    show_log_need_to_deal(); cout << endl;
    string id;
    
    cout << "���������ѱ��ò͵Ķ������:" ;cin >> id; id += ' ';
    fstream stream;
	stream.open("reverse_log.txt",ios::in);
	queue<string> t;
	string log;
	while(getline(stream,log))
    {   
    	if(log_to_item(log,9) == id) log += "1";
    	t.push(log);
	}	
	stream.close();
	stream.open("reverse_log.txt",ios::out | ios::trunc);
	
	while(!t.empty())
	{
		stream << t.front() << endl;
		t.pop();
	}
	stream.close();
	cout << "�Ѿ��������!" << endl;
}


void store_keeper::add_menu_item()
{
	ofstream write;
	ifstream write_id;
	
	write_id.open("index.txt");
	string line;
	string ids;int id;
	queue<string> temp; 
	
	while(getline(write_id,line))
	{   
	    int pos1 = line.find(" ") + 1;
		int pos2 = line.find(" ",pos1);
		string lines = line.substr(0, pos1 - 1);
		
		if(lines != "the_meal") temp.push(line);
		else 
		{
			ids = line.substr(pos1, pos2 - pos1) ;
			istringstream ss(ids);
            ss >> id;
            line = lines + " " + to_string(id + 1);
            temp.push(line);
		}
		
	}
	write_id.close();
	
	//id
	write.open( "index.txt",ios::out | ios::trunc);
	
	
	while(!temp.empty())
	{     
	    if(temp.front() != " ")  
		write << temp.front() << endl;
		temp.pop();
	}
	
	write.close();
	
	write.open( "menu.txt",ios::app);
	if (!write.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file to read\n";
			return;
		} 
	string item;
	string money;
	cout << "�������Ʒ:" << endl;
	cin >> item;
	cout << "������۸�:" << endl;
	cin >> money;
	
	 write  << left << setw(5) << ids << setw(20) << item << setw(8) << money << endl; 
	write.close();
}

void store_keeper::delt_menu_item()
{   

    show_menu();
    cout << "��������Ҫɾ���Ĳ�Ʒ���" << endl;
    string delt_item;
    cin >> delt_item;
    
	queue<string> meal_menu; 
	ifstream read;
	ofstream write;
	string line;
	
	read.open("menu.txt");
	while(getline(read,line))
	{   
	    int pos1 = line.find(" ") + 1;
		//int pos2 = line.find(" ",pos1);
		string lines = line.substr(0, pos1 - 1);
		if(lines != delt_item) meal_menu.push(line);
		
	}
	read.close();
	
	
	write.open( "menu.txt",ios::in | ios::trunc);
	
	
	while(!meal_menu.empty())
	{
		write << meal_menu.front() << endl;
		meal_menu.pop();
	}
	
	write.close();
}
