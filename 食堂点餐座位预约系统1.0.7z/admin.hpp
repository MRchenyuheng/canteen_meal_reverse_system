#include"user.hpp"

#pragma once

#include<iostream>
#include<algorithm>
#include<cstring>
#include<fstream>
#include<iomanip> 
#include<sstream>
#include<queue>

using namespace std;

const int T = 1e3;

char mapss[T][T];
//bool is_set[N][N];
int mapxx;
int mapyy;

class admin : public user
{

public:
	void change_size();
	void show_map();
	void init_map();
	void add_map();
	void delt_map();

private:
	string user_id;
	string user_name;
		
};

void admin::show_map()
{
     init_map();

	for(int i = 0;i <= mapxx;i ++)
	{for(int j = 0;j <= mapyy;j ++)
	{
	   if(j == 0) cout  << left << setw(3) << i ; 
	   else if(i == 0) cout << left << setw(3) <<  j;
       else cout << left << setw(3) << mapss[i][j] ;
    }
	  cout << endl; 
    }
}

void admin::init_map()
{
    
    
    for(int i = 0;i < T;i ++)
    for(int j = 0;j < T;j ++)
      mapss[i][j] = '0';
      
	ifstream read;
	string map;
	read.open("map.txt",ios::in);
		if (!read.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file map.txt to read\n";
			return;
		}
	
	bool f = true;
	
	while(getline(read,map))
	  {
	  	int pos1 = map.find(" ") + 1;
		int pos2 = map.find(" ",pos1);
		
		string sxx = map.substr(0, pos1 - 1);
		string syy = map.substr(pos1, pos2 - pos1) ;
		istringstream xxx(sxx);
	    istringstream yyy(syy);
	    int x_int; xxx >> x_int;
	    int y_int; yyy >> y_int;
	    if(f)
	    {
	    	 mapxx = x_int;
	    	 mapyy = y_int;
	    	 f = false;
		}
		else {
		mapss[x_int][y_int] = '#';
	    //is_set[x_int][y_int] = true;
	   }
	    
	  }
    
    read.close();
    
}


void admin::change_size()
{    
    cout << "��������ĺ��ͼ�Ĵ�С����" << endl;
    queue<string> temp;
	  string x; 
	  string y;
	 cout << "x:";cin >> y;
	 cout << "y:";cin >> x;
	bool f = true;
	ifstream read;string line;
	read.open("map.txt",ios::in);
	while(getline(read,line))
    {
		if(f) f = false;
		else temp.push(line);
	}	
	read.close();
	
	ofstream write;
	write.open("map.txt",ios::out|ios::trunc);
	write << x << ' ' << y << endl; 
	
	while(!temp.empty())
    {
    	write << temp.front() << endl;
    	temp.pop();
 	}	
 	
 	write.close();
 	
 	
}



void admin::add_map()
{   
    int n;
    cout << "������Ҫ���뼸���㣺" << endl;
	cin >> n; 
	
    ofstream write;
    write.open("map.txt",ios::out|ios::app);
    
	string x;
	string y;
	
	for(int i = 1;i <= n;i ++)
	{
	cout << i << ":" << endl;
	cout << "x:";cin >> y;
	cout << "y:";cin >> x;
	string log = x + ' ' + y;
	write << log << endl;
   
   }
   
   write.close();
   	
	
}

void admin::delt_map()
{   
    cout << "��������Ҫɾ����ǵĴ�����" << endl;
    int n;cin >> n;
    
    string delt_x;
    string delt_y;
    for(int i = 1;i <= n ;i ++)
    {
	
	cout << i << ":" << endl;
    cout << "x:";cin >> delt_y;
    cout << "y:";cin >> delt_x;
    
	queue<string> map_item; 
	ifstream read;
	ofstream write;
	string line;
	
	bool f = false;
	
	read.open("map.txt");
	while(getline(read,line))
	{   
	    int pos1 = line.find(" ") + 1;
		int pos2 = line.find(" ",pos1);
		string x_of_now = line.substr(0, pos1 - 1);
		string y_of_now = line.substr(pos1,pos2 - pos1);
	     
		 if(f) if( (x_of_now != delt_x )|| (y_of_now != delt_y)) map_item.push(line);
	     else {
	     map_item.push(line);
		 f = true;
	    }   
		
	}
	read.close();
	
	
	write.open( "map.txt",ios::in | ios::trunc);
	
	
	while(!map_item.empty())
	{
		write << map_item.front() << endl;
		map_item.pop();
	}
	
	write.close();
	
   }
   
}
