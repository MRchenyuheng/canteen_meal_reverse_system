#pragma once

#include<iostream>
#include<algorithm>
#include<cstring>
#include<fstream>
#include<ctime>
#include<sstream>

using namespace std;


string get_data()
{
	time_t now = time(NULL);
	tm* tm_t = localtime(&now);
	std::stringstream ss;
	ss << tm_t->tm_year + 1900 << "-" ;
	if(tm_t->tm_mon + 1 < 10) ss << 0;
	ss << tm_t->tm_mon + 1 << "-" ;
	if(tm_t->tm_mday < 10) ss << 0;
	ss << tm_t->tm_mday;
   return ss.str();
}


class user
{

public:
	
	user() {};
	string get_name() const { return user_name; }
	string get_name() { return user_name; }
    string get_id() const { return user_id; }
    void write_id(string id);
    void write_name(string name);
    //void show_map();
    void show_menu();
    string log_to_item(string log,int choice);
    string get_txt_name(); 
    

private:
	string user_id;
	string user_name;
	
};

string user::get_txt_name()
{
	string txt_name = "reserve_log\\" + get_data() + "_reserve_log.txt";
	return txt_name;
}

inline void user::write_id(string id)
{
	user_id = id;
}

inline void user::write_name(string name)
{
	user_name = name;
}

string user::log_to_item(string log,int choice)
{   
    //if(log == " ") return " ";

	int pos1 = log.find(" ") + 1; string show_time_hour = log.substr(0, pos1 - 1);

	int pos2 = log.find(" ",pos1) + 1; string show_time_min = log.substr(pos1,pos2 - pos1);
	int pos3 = log.find(" ",pos2) + 1; string show_x = log.substr(pos2,pos3 - pos2);
	int pos4 = log.find(" ",pos3) + 1; string show_y = log.substr(pos3,pos4 - pos3);
	int pos5 = log.find(" ",pos4) + 4; 
	int pos6 = log.find(" ",pos5) + 1; string meal_name = log.substr(pos5,pos6 - pos5); 
	int pos7 = pos5 + 20;
	int pos8 = log.find(" ",pos7) + 1; string show_money = log.substr(pos7,pos8 - pos7); 
	int pos9 = pos7 + 9;
	int pos10 = log.find(" ",pos9) + 1; string show_name = log.substr(pos9,pos10 - pos9);
	int pos11 = log.find(" ",pos10 + 1) + 1; string show_id = log.substr(pos10,pos11 - pos10);
	int pos12 = log.find(" ",pos11) + 1; string show_log_id = log.substr(pos11,pos12 - pos11);
    int pos13 = log.find(" ",pos12) + 1; string show_status = log.substr(pos12,pos13 - pos12);
	
	if(choice == 1)        return show_time_hour;
	else if(choice == 2)   return show_time_min;
	else if(choice == 3)   return show_x;
	else if(choice == 4)   return show_y;
	else if(choice == 5)   return meal_name;
	else if(choice == 6)   return show_money;
	else if(choice == 7)   return show_name;
	else if(choice == 8)   return show_id;
	else if(choice == 9)   return show_log_id;
	else if(choice == 10)   return show_status;
}

void user::show_menu()
{
	ifstream read;
	string menu;
	read.open("menu.txt",ios::in);
		if (!read.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file map.txt to read\n";
			return;
		}
	
	
	while(getline(read,menu))
	  cout << menu << endl;
    
    read.close();
    return;
}
