#include"admin.hpp"
#include"store_keeper.hpp"
#include"customer.hpp"

#include<iostream>
#include<fstream>
#include<ctime>
#include<sstream>
#include<windows.h>
#include<iomanip>
#include<queue>
#include<vector> 
#include "conio.h"



using namespace std;
void menu_show();
bool menu(int choice);
void log_in_show();
void log_in();
void log_in_table(int choice);
void register_system();
void register_table(int choice);
void register_system_show();
string set_pd();
string get_time();
void head_show();
void store_keeper_system(string id,string name);
void store_keeper_system_menu_show(string name);
void customer_system(string id,string name);
void customer_system_menu_show(string name);
void admin_system(string id,string name);
void admin_system_menu_show(string name);

void head_show()
{  
    system("cls");
    cout << "##################################################" << endl;
	cout << "�Ͼ���Ϣ���̴�ѧ �������Ԥ��ϵͳ��ӭ����        #" << endl; 
	cout << "                                                 #" <<endl;
	cout << "Welcome to canteen_meal_reserve_system of NUIST! #" << endl;
    cout << "##################################################" << endl;
    cout << "���ڵ�ʱ����:                                    #" << endl; 
	cout << get_time()  << "                              #"<<endl; 
	cout << "##################################################" << endl;
	return;
}

string get_time()
{
	time_t now = time(NULL);
	tm* tm_t = localtime(&now);
	std::stringstream ss;
	ss << tm_t->tm_year + 1900 << "-" ;
	if(tm_t->tm_mon + 1 < 10) ss << 0;
	ss << tm_t->tm_mon + 1 << "-" ;
	if(tm_t->tm_mday < 10) ss << 0;
	ss << tm_t->tm_mday	<< " " ;
    if(tm_t->tm_hour < 10) ss << 0;
	ss <<  tm_t->tm_hour << ":" ;
	if(tm_t->tm_min < 10) ss << 0;
	ss << tm_t->tm_min << ":" ;
	if(tm_t->tm_sec < 10) ss << 0;
	 ss << tm_t->tm_sec;
 
   return ss.str();
}
 

void menu_show()
{
	
	head_show();
	cout << "��������,���в���:"<< endl;
	cout << "0:�˳�����" << endl;
	cout << "1:��¼" << endl; 
	cout << "2:ע��" << endl;
	
	 
}

bool menu(int choice)
{
	if(!choice) return false;
    head_show();
	
	switch(choice){
		case 1:
			log_in();
			menu_show();
			cin >> choice;
			menu(choice);
			break;
		case 2:
			register_system();
			menu_show();
			cin >> choice;
			menu(choice);
			break;
		default:
			cout << "�������!" << endl;
			system("pause");
			menu_show();
			cin >> choice;
			menu(choice);
			break;		
			
	}
}
void register_table(int choice)
{
	
	   if(choice == 1){
	    	
			cout << "�������ڽ��й˿�ע�᣺" << endl;
			cout << "##################################################" << endl;
     	}
		else if(choice == 2){
			cout << "�������ڽ����̼�ע�᣺" << endl;
			cout << "##################################################" << endl;
    	}
}

void register_system_show()
{   
    head_show();
	cout << "�������֣�ѡ��ע���ɫ" << endl;
	cout << "1:�˿�" << endl;
	cout << "2.�̼�" << endl; 
}

string set_pd()
{   
    string passwords;
	char pd;
	int i = 0;
	while(1)
	{
		pd = _getch();        //��ȡ���������
		if (pd == 13)		//�س�����
		{
			break;
		}
		if (pd == 8)			//�˸�
		{
			if (passwords.length() == 0)		//�����һ����Ϊ�˸��
			{
				cout << "����Ϊ��,���������룺"  << endl;
				continue;
			}
			cout << "\b \b";
			i++;							//�����Ҫɾ�����ַ�
			passwords[passwords.length() - i] = '\0';
 
		}
		else
		{
			passwords += pd;
			cout << "*";
		}
		
	}
	return passwords;
}
void register_system()
{

register_system_show();

ifstream read;string line;

int choice;cin >> choice;
register_table(choice);
string in_number;
cout << "������󶨵ĵ绰����:" ; cin >> in_number;

		if(choice == 1){
		read.open("Account_system_customer.txt", ios::in);
     	}
		else if(choice == 2){
		read.open("Account_system_storekeeper.txt", ios::in);
    	}

while(getline(read,line))
{
	int pos1 = line.find(" ") + 1;      string only_id = line.substr(0, pos1 - 1);
	int pos2 = line.find(" ",pos1) + 1; string passwords = line.substr(pos1,pos2 - pos1);
	int pos3 = line.find(" ",pos2) + 1; string the_name = line.substr(pos2,pos3 - pos2);
	int pos4 = line.find(" ",pos3) + 1; string phone_number = line.substr(pos3,pos4 - pos3);
	if(phone_number == in_number)
	{
		cout << "��ǰ�����Ѿ���ע�ᣡ" << endl;
		system("pause");
		return; 
	}

string names;
cout << "�����������û�����"; cin >> names;

cout << "���������룺";   string set_passwords = set_pd();
cout << endl;
cout << "�ٴ�ȷ�����룺"; string insure_paswords = set_pd();
if(set_passwords != insure_paswords) 
{
	cout << "�������벻ƥ�䣬������ע�ᣡ" << endl;
	return; 
}
	
read.close();

	/////////////////////////////////////////////////////////����id		
	    ifstream write_id;
	    ofstream write;
		string ids;int id;
	    queue<string> temp; 
	    write_id.open("index.txt");
	    
	    while(getline(write_id,line))
	{   
	    int pos1 = line.find(" ") + 1;
		int pos2 = line.find(" ",pos1);
		string lines = line.substr(0, pos1 - 1);
		
		if(lines != "only_id") temp.push(line);
		else 
		{
			ids = line.substr(pos1, pos2 - pos1) ;
			istringstream ss(ids);
            ss >> id;
            line = lines + " " + to_string(id + 1);
            temp.push(line);
		}
		
	}
	write_id.close();
	
	//id
	write.open( "index.txt",ios::in | ios::trunc);
	
	
	while(!temp.empty())
	{     
	    if(temp.front() != " ")  
		write << temp.front() << endl;
		temp.pop();
	}
	
	write.close();
/////////////////////////////////////////////////////////����id	
cout << endl;
cout << "����ƽ̨Ψһ�˺��ǣ�"  << ids << endl;
cout << "���μǣ�" << endl;
system("pause");

string logs = ids + " " + set_passwords + " " + names + " " + in_number;

queue<string>the_temp;
the_temp.push(logs);
ifstream inFile;
if(choice == 1){
		inFile.open("Account_system_customer.txt", ios::in);
     	}
		else if(choice == 2){
		inFile.open("Account_system_storekeeper.txt", ios::in);
    	}
string get_info;
while(getline(inFile,get_info)) the_temp.push(get_info);


ofstream write_info;
if(choice == 1){
		write_info.open("Account_system_customer.txt", ios::out|ios::trunc);
     	}
		else if(choice == 2){
		write_info.open("Account_system_storekeeper.txt", ios::out|ios::trunc);
    	}
while(!the_temp.empty())
{
write_info << the_temp.front() << endl;
the_temp.pop();
}
write_info.close();

return;
}
	
}
void log_in_show()
{   
   // time_show();
	cout << "�������֣�ѡ���¼��ɫ" << endl;
	cout << "1:����Ա"  << endl;
	cout << "2:�˿�" << endl;
	cout << "3.�̼�" << endl; 
}

void log_in_table(int choice)
{
	    head_show();
		
		if(choice == 1)
		{
		
			cout << "�������ڽ��й���Ա��¼��" << endl;
			cout << "##################################################" << endl;
	    }
		else if(choice == 2){
	    	
			cout << "�������ڽ��й˿͵�¼��" << endl;
			cout << "##################################################" << endl;
     	}
		else if(choice == 3){
			cout << "�������ڽ����̼ҵ�¼��" << endl;
			cout << "##################################################" << endl;
    	}
}

void log_in()
	{   
	    log_in_show();
	
		string line;
		
		int choice;cin >> choice;
	    string id;string password;
	    
	    int cnt = 1;
		
		while(cnt < 4) 
		{
		
		ifstream read;
		if(choice == 1)
		{
			read.open("Account_system_admin.txt", ios::in);
	    }
		else if(choice == 2){
		read.open("Account_system_customer.txt", ios::in);
     	}
		else if(choice == 3){
		read.open("Account_system_storekeeper.txt", ios::in);
    	}
    	
    	head_show();
    	log_in_table(choice);
    	
		
		if(cnt >= 2){
		cout << "�����ٴγ��ԣ�һ��3�λ��ᣡ" << endl;
		cout << "Ŀǰ������" << cnt << "��" << endl;
	   }
	   
	   
	    cout << "�����������˺�:"<< endl;cin >> id;
	    cout << "��������������:" << endl;cin >> password;
		
		if (!read.is_open()) {
			cout << "ϵͳ���� ������ϵ�����ߡ�\n ������fail to open file to read\n";
			return;
		}
		else {
			
			while (getline(read, line))
			{
				string system_id = line.substr(0, line.find(" "));
				if (system_id == "end")
				{   
				    head_show();
				    cnt ++; 
					cout << "�˺Ŵ���û���ҵ����˺�!" << endl;
					system("pause");
					
				
				}
				int pos1 = line.find(" ") + 1;
				int pos2 = line.find(" ",pos1);
				
				string system_password =  line.substr(pos1, pos2 - pos1) ;
				
				if (system_id == id) //��¼�ɹ� 
					if (system_password == password)
					{   
					     int pos1 = line.find(" ") + 1;      string only_id = line.substr(0, pos1 - 1);
	                     int pos2 = line.find(" ",pos1) + 1; string passwords = line.substr(pos1,pos2 - pos1);
	                     int pos3 = line.find(" ",pos2) + 1; string the_name = line.substr(pos2,pos3 - pos2);
					
					     if(choice == 3) store_keeper_system(only_id,the_name);
					     else if(choice == 2) customer_system(only_id,the_name);
					     else if(choice == 1) admin_system(only_id,the_name);
						 return;					     
					}
					else
					{  
					    head_show(); 
						cout << "�������!" << endl;
						cnt ++;
						system("pause");
						
					}	
           }
             }
             read.close();
       }
       
      
       cout << "��¼ʧ�ܣ�" << endl;
       return;
}

void admin_system_menu_show(string name)
{
	head_show();
	cout << "�����ǹ���Ա�ͻ���" << endl;
	cout << "##################################################" << endl;
	cout << name << "����Ա,��ӭ��!" << endl;
	cout << "##################################################" << endl;
	cout << "�������֣����в���:" << endl;
	cout << "0:�˳�ϵͳ" << endl; 
	cout << "1:�鿴��ͼ"  << endl;
	cout << "2:�޸ĵ�ͼ��С" << endl;
	cout << "3:�����ϰ���" << endl; 
	cout << "4:ɾ���ϰ���" << endl;
}


void admin_system(string id,string name)
{   
    
	
	admin c;
	c.write_id(id);
	c.write_name(name);
	int choice;  

	do
	{
    admin_system_menu_show(name);
    cin >> choice;
	if(choice == 1)      { system("cls");c.show_map(); system("pause");    }
	else if(choice == 2) { system("cls");c.change_size();  system("pause");}
	else if(choice == 3) { system("cls");c.add_map(); system("pause");     }
    else if(choice == 4) { system("cls");c.delt_map();system("pause");     }
   
   }while(choice != 0);
	
	
}



void store_keeper_system_menu_show(string name)
{
	head_show();
	cout << "�������̼ҿͻ���" << endl;
	cout << "##################################################" << endl;
	cout << name << ",��ӭ��!" << endl;
	cout << "##################################################" << endl;
	cout << "�������֣����в���:" << endl;
	cout << "0:�˳�ϵͳ" << endl; 
	cout << "1:�鿴�˵�"  << endl;
	cout << "2:���Ӳ�Ʒ" << endl;
	cout << "3:ɾ����Ʒ" << endl; 
	cout << "4:�鿴��Ҫ�����Ķ���" << endl; 
	cout << "5:��������" << endl; 
}



void store_keeper_system(string id,string name)
{   
   
	store_keeper a;
	a.write_id(id);
	a.write_name(name);
	int choice;
	
	do
	{
    store_keeper_system_menu_show(name);
    cin >> choice;
	if(choice == 1)
	{
	system("cls");
	a.show_menu();
	system("pause");
	store_keeper_system_menu_show(a.get_name());
    }
    else if(choice == 2)
    {
    system("cls");
     a.add_menu_item();
     cout << "���Ӳ�Ʒ�ɹ���" << endl;
      system("pause");
    store_keeper_system_menu_show(a.get_name());
   }
    else if(choice == 3)
    {
    system("cls");
    a.delt_menu_item();
    cout << "ɾ����Ʒ�ɹ���" << endl;
     system("pause");
    store_keeper_system_menu_show(a.get_name());
   }
   else if(choice == 4)
   {
   	system("cls");
   	cout << "���¶�����Ҫ����" << endl;
   	cout << endl;
    a.show_log_need_to_deal();
     system("pause");
   }
   else if(choice == 5)
   {
   	system("cls");
   	cout << "���¶�����Ҫ����" << endl;
   	cout << endl;
    a.deal_with_the_log();
     system("pause");
   }
   }while(choice);
}


void customer_system_menu_show(string name)
{
	head_show();
	cout << "�����ǹ˿Ϳͻ���" << endl;
	cout << "##################################################" << endl;
	cout << name << ",��ӭ��!" << endl;
	cout << "##################################################" << endl;
	cout << "�������֣����в���:" << endl;
	cout <<  "0:�˳�ϵͳ" << endl; 
	cout << "1:����Ԥ��"  << endl;
	cout << "2:�鿴��λ���" << endl;
	cout << "3:�鿴������λ���" << endl; 
	cout << "4:�鿴�˵�" << endl; 
	cout << "5:�鿴����״̬" << endl;
}

void customer_system(string id,string name)
{   
    
	
	customer b;
	b.write_id(id);
	b.write_name(name);
   int choice; 
   
    do
    {
    customer_system_menu_show(name);
    cin >> choice;
	  if(choice == 1)
	  { 
	    system("cls");
	    b.reverse_meal();
	    system("pause");
	  }
	  else if(choice == 2)
	  { 
	    system("cls");
	  	string hour;string min;
	  	cout << "ʱ:";cin >> hour;
		cout << "��:" ;cin >> min;
	  	b.draw_map(hour,min);
	  	system("pause");
	 } 
	 else if(choice == 3)
	 {
	 	system("cls");
	    b.show_map_now();
	    system("pause");
	 }
	  else if(choice == 4)
	 {
	 	system("cls");
	    b.show_menu();
	    system("pause");
	 }
	 else if(choice == 5)
	 {
	 	system("cls");
	    b.show_the_log();
	    system("pause");
	 }
    }while(choice);
}
int main()
{   
    //system("dir");
    menu_show();
    int choice;
    cin >> choice;
    while(menu(choice));
    return 0;
	
}
